package com.sellsync.api.domain.erp.enums;

public enum PostingType {
    PRODUCT_SALES,
    SHIPPING_FEE,
    PRODUCT_CANCEL,
    SHIPPING_CANCEL
}
